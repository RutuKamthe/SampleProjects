//
//  ViewResource.swift
//  MasterMovies
//
//  Created by Admin on 07/09/22.
//

import Foundation
struct UserResource {
    func userResponse(completion: @escaping (_ Result: [UserResponse]) -> Void) {
        let httpUtility = HttpUtility()
        let employeeEndpoint = ApiEndpoints.photoThumb
        let requestUrl = URL(string: employeeEndpoint)!
        httpUtility.getApi(requestUrl: requestUrl, resultType: [UserResponse].self) { (albumApiResponse) in
            _ = completion(albumApiResponse)
        }
    }
}
