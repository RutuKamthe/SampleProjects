//
//  Common.swift
//  MasterMovies
//
//  Created by Admin on 07/09/22.
//

import Foundation

struct Constants {
    static let ErrorAlertTitle = "Error"
    static let OkAlertTitle = "Ok"
    static let CancelAlertTitle = "Cancel"
}

struct ApiEndpoints {
    static let photoThumb = "https://jsonplaceholder.typicode.com/photos"
    static let url = "https://youtu.be/6mBO2vqLv38"
    static let user = "https://jsonplaceholder.typicode.com/users"
}
