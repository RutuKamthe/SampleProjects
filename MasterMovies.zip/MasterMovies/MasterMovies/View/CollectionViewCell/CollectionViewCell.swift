//
//  CollectionViewCell.swift
//  MasterMovies
//
//  Created by Admin on 07/09/22.
//

import Foundation
import UIKit
class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var photo: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func cellFillUp(data : UserResponse) {
        photo?.downloaded(from: data.url)
    }
}
