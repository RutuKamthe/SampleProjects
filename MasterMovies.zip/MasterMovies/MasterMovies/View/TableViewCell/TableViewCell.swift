//
//  TableViewCell.swift
//  MasterMovies
//
//  Created by Admin on 07/09/22.
//

import Foundation
import UIKit
class TableViewCell: UITableViewCell {
    @IBOutlet var lblName: UILabel!
    @IBOutlet weak var photo: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func cellFillUp(data : UserResponse) {
        lblName.text = data.title
        photo?.downloaded(from: data.thumbnailUrl)
        
    }
}
