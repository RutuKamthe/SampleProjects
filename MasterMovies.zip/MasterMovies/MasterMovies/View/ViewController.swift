//
//  ViewController.swift
//  MasterMovies
//
//  Created by Admin on 07/09/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var collectionView: UICollectionView!
    @IBOutlet var listViewBtn: UIButton!
    @IBOutlet var gridViewBtn: UIButton!
    @IBOutlet var tableView: UITableView!
    private var userViewModel = UserViewModel()
    var userTableData: [UserResponse]? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userViewModel.delegate = self
        addTarget()
        collectionView.register(UINib(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionViewCell")
        collectionView.contentInset = UIEdgeInsets.init(top: 0, left: 10, bottom: 0, right: 10)
        collectionView.decelerationRate = UIScrollView.DecelerationRate.fast
        let cellSize = CGSize(width:80, height:80)
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.itemSize = cellSize
        collectionView.setCollectionViewLayout(layout, animated: true)
        
        callApi()
    }
    
    func addTarget() {
        gridViewBtn.addTarget(self, action: #selector(gridView), for: .touchUpInside)
        listViewBtn.addTarget(self, action: #selector(listView), for: .touchUpInside)
    }
    
    func callApi() {
        userViewModel.userRequest()
    }
}

extension ViewController {
    @objc func listView() {
        collectionView.isHidden = true
        tableView.isHidden = false
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    @objc func gridView() {
        collectionView.isHidden = false
        tableView.isHidden = true
        DispatchQueue.main.async {
            self.reloadCollectionView(click: false)
        }
    }
}

extension  ViewController : UserViewModelDelegate{
    func didUserResponse(error: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: Constants.ErrorAlertTitle, message: error, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: Constants.OkAlertTitle, style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
    
    func didUserResponse(UserRespone: [UserResponse]) {
        if(UserRespone.count > 0) {
            self.userTableData = UserRespone
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
}

