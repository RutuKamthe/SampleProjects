//
//  ViewExtension.swift
//  MasterMovies
//
//  Created by Admin on 07/09/22.
//

import Foundation
import UIKit

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    // MARK: - Table view datasource method
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userTableData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifierParents = "TableViewCell"
        var cell: TableViewCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifierParents) as? TableViewCell
        if cell == nil {
            tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: cellIdentifierParents)
            cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifierParents) as? TableViewCell
        }
        if let dict = userTableData?[indexPath.row] {
            cell?.cellFillUp(data:dict)
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        reloadCollectionView(click: true)
    }
}


extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        userTableData?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as? CollectionViewCell
        if let dict = userTableData?[indexPath.row] {
            cell?.cellFillUp(data: dict)
        }
        return cell!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        reloadCollectionView(click: true)
    }
    
    func reloadCollectionView(click: Bool) {
        tableView.isHidden = true
        collectionView.isHidden = false
        let layout = UICollectionViewFlowLayout()
        var cellSize = CGSize()
        if click {
            cellSize = CGSize(width: self.view.frame.width, height: self.view.frame.height)
            layout.scrollDirection = .horizontal
        }else {
            cellSize = CGSize(width: self.view.frame.width/2.3, height: self.view.frame.height/5)
            layout.scrollDirection = .vertical
        }
        layout.itemSize = cellSize
        collectionView.setCollectionViewLayout(layout, animated: true)
        collectionView.reloadData()
    }
}
