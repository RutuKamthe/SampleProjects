//
//  Model.swift
//  MasterMovies
//
//  Created by Admin on 07/09/22.
//

import Foundation
struct UserResponse: Decodable {
    let albumId, id : Int
    let title, url, thumbnailUrl : String
}
