//
//  ValidationResult.swift
//  MasterMovies
//
//  Created by Admin on 07/09/22.
//

import Foundation

struct ValidationResult {
    let success: Bool
    let error : String?
}
